Included in this package is a checkout of XSLTForms version 594, from 2014-04-16.

You can retrieve the same files at

	https://github.com/AlainCouthures/xsltforms/tree/820e52e317df7e0c26b83eeddacd169683469d7c
	
The files build.xml, expath-pkg.xml, and repo.xml are part of the eXist-db package system and do not belong to XSLTForms.

For more information on XSLTForms, consult <http://www.agencexml.com/xsltforms>.

An eXist-db app, XLSTForms-Demo, containing examples of XSLTForms running with eXist-db, is available from the eXist-db Package Manager.