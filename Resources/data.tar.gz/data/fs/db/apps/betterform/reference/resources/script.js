/*
 * Copyright (c) 2012. betterFORM Project - http://www.betterform.de
 * Licensed under the terms of BSD License
 */

var embedInline = function() {
    return {
            test : function() {
                alert("Hello from external JavaScript file.");
            }
    };
}();

