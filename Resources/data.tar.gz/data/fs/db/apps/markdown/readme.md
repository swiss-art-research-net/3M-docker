# XQuery Markdown Parser

A markdown parser written in XQuery. Based on regular expressions and
fast enough for rendering small to mid-sized documents.

The parser extends the [original markdown][2] proposal with fenced code 
blocks and tables. These are additional features found in [Github flavored markdown][1].

[1]: https://help.github.com/articles/github-flavored-markdown
[2]: http://daringfireball.net/projects/markdown/syntax
